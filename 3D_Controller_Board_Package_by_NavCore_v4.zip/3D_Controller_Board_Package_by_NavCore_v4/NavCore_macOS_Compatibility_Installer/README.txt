NavCore 3D Controller Board Package
macOS Compatibility Installer

How to use:
1. Unzip this folder.
2. Right-click Install_macOS_Compatibility.command.
3. Choose Open.
4. Confirm Open if macOS asks.
5. Choose the correct boards.txt file if several are found.
6. Fully quit and reopen Arduino IDE.
7. Select:
   Tools > Board > SpaceMouse Compact Test
8. Upload the firmware again.

What it does:
- Searches common Arduino AVR boards.txt locations
- Supports Arduino IDE 1.x and 2.x paths
- Creates a backup of boards.txt
- Uses sudo if the file is protected
- Replaces an existing navcore3d entry with the macOS compatibility version

Changes:
- Board name: SpaceMouse Compact Test
- USB Product: SpaceMouse Compact
- USB Manufacturer: 3Dconnexion
- VID: 0x256F
- PID: 0xC635
