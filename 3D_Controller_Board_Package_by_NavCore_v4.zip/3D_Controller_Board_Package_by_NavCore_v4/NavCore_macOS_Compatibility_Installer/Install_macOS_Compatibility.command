#!/bin/bash

clear
echo "============================================================"
echo " NavCore 3D Controller Board Package"
echo " macOS Compatibility Installer"
echo "============================================================"
echo ""

BOARD_BLOCK='
##############################################################
# 3D Controller Board Package
# by NavCore
#
# macOS Compatibility Patch
#
# Target board: Arduino Pro Micro / ATmega32U4 / 5V / 16 MHz
##############################################################

navcore3d.name=SpaceMouse Compact Test

navcore3d.vid.0=0x256F
navcore3d.pid.0=0xC635

# Upload settings - Caterina bootloader / Pro Micro / Leonardo style
navcore3d.upload.tool=avrdude
navcore3d.upload.tool.default=avrdude
navcore3d.upload.tool.serial=avrdude
navcore3d.upload.protocol=avr109
navcore3d.upload.maximum_size=28672
navcore3d.upload.maximum_data_size=2560
navcore3d.upload.speed=57600
navcore3d.upload.disable_flushing=true
navcore3d.upload.use_1200bps_touch=true
navcore3d.upload.wait_for_upload_port=true

# Bootloader settings
navcore3d.bootloader.tool=avrdude
navcore3d.bootloader.low_fuses=0xff
navcore3d.bootloader.high_fuses=0xd8
navcore3d.bootloader.extended_fuses=0xcb
navcore3d.bootloader.file=caterina/Caterina-Leonardo.hex
navcore3d.bootloader.unlock_bits=0x3F
navcore3d.bootloader.lock_bits=0x2F

# Build settings
navcore3d.build.mcu=atmega32u4
navcore3d.build.f_cpu=16000000L
navcore3d.build.vid=0x256F
navcore3d.build.pid=0xC635
navcore3d.build.usb_product="SpaceMouse Compact"
navcore3d.build.usb_manufacturer="3Dconnexion"
navcore3d.build.board=AVR_3D_CONTROLLER
navcore3d.build.core=arduino
navcore3d.build.variant=leonardo
navcore3d.build.extra_flags={build.usb_flags}
'

echo "Searching for Arduino AVR boards.txt..."
echo ""

FOUND_FILES=()

while IFS= read -r FILE; do
  FOUND_FILES+=("$FILE")
done < <(find "$HOME/Library/Arduino15/packages" -path "*/hardware/avr/*/boards.txt" 2>/dev/null)

if [ -f "/Applications/Arduino.app/Contents/Java/hardware/arduino/avr/boards.txt" ]; then
  FOUND_FILES+=("/Applications/Arduino.app/Contents/Java/hardware/arduino/avr/boards.txt")
fi

while IFS= read -r FILE; do
  FOUND_FILES+=("$FILE")
done < <(find "/Applications" -path "*/hardware/arduino/avr/boards.txt" 2>/dev/null)

UNIQUE_FILES=()
for FILE in "${FOUND_FILES[@]}"; do
  SKIP=0
  for EXISTING in "${UNIQUE_FILES[@]}"; do
    if [ "$FILE" = "$EXISTING" ]; then
      SKIP=1
      break
    fi
  done
  if [ "$SKIP" -eq 0 ]; then
    UNIQUE_FILES+=("$FILE")
  fi
done

if [ ${#UNIQUE_FILES[@]} -eq 0 ]; then
  echo "No boards.txt file was found automatically."
  echo ""
  echo "Manual mode:"
  echo "Drag and drop your boards.txt file into this Terminal window, then press Enter:"
  read -r CUSTOM_FILE

  CUSTOM_FILE="${CUSTOM_FILE%\"}"
  CUSTOM_FILE="${CUSTOM_FILE#\"}"
  CUSTOM_FILE="${CUSTOM_FILE%\'}"
  CUSTOM_FILE="${CUSTOM_FILE#\'}"
  CUSTOM_FILE="$(printf '%s' "$CUSTOM_FILE" | sed 's/\\ / /g')"

  if [ ! -f "$CUSTOM_FILE" ]; then
    echo ""
    echo "Error: file not found:"
    echo "$CUSTOM_FILE"
    echo ""
    read -p "Press Enter to close..."
    exit 1
  fi

  TARGET_FILE="$CUSTOM_FILE"

elif [ ${#UNIQUE_FILES[@]} -eq 1 ]; then
  TARGET_FILE="${UNIQUE_FILES[0]}"
  echo "Found one boards.txt file:"
  echo "$TARGET_FILE"

else
  echo "Several boards.txt files were found."
  echo "Choose the Arduino AVR boards.txt file to modify:"
  echo ""

  select TARGET_FILE in "${UNIQUE_FILES[@]}"; do
    if [ -n "$TARGET_FILE" ]; then
      break
    fi
    echo "Invalid choice."
  done
fi

echo ""
echo "Selected file:"
echo "$TARGET_FILE"
echo ""

if [ ! -w "$TARGET_FILE" ]; then
  echo "This file is protected."
  echo "Your Mac password may be required."
  NEED_SUDO=1
else
  NEED_SUDO=0
fi

BACKUP_FILE="$TARGET_FILE.backup-$(date +%Y%m%d-%H%M%S)"

if [ "$NEED_SUDO" -eq 1 ]; then
  sudo cp "$TARGET_FILE" "$BACKUP_FILE"
else
  cp "$TARGET_FILE" "$BACKUP_FILE"
fi

if [ $? -ne 0 ]; then
  echo "Error: backup failed."
  echo ""
  read -p "Press Enter to close..."
  exit 1
fi

echo "Backup created:"
echo "$BACKUP_FILE"
echo ""

if grep -q "navcore3d.name=" "$TARGET_FILE"; then
  echo "Existing navcore3d entry found."
  echo "It will be replaced with the macOS compatibility version."
  echo ""

  if [ "$NEED_SUDO" -eq 1 ]; then
    sudo perl -0pi -e 's/\n##############################################################\n#.*?navcore3d\.build\.extra_flags=\{build\.usb_flags\}\n//s' "$TARGET_FILE"
  else
    perl -0pi -e 's/\n##############################################################\n#.*?navcore3d\.build\.extra_flags=\{build\.usb_flags\}\n//s' "$TARGET_FILE"
  fi
fi

if [ "$NEED_SUDO" -eq 1 ]; then
  printf "\n%s\n" "$BOARD_BLOCK" | sudo tee -a "$TARGET_FILE" > /dev/null
else
  printf "\n%s\n" "$BOARD_BLOCK" >> "$TARGET_FILE"
fi

if grep -q "navcore3d.name=SpaceMouse Compact Test" "$TARGET_FILE"; then
  echo "Installation complete."
  echo ""
  echo "Next steps:"
  echo "1. Fully quit Arduino IDE."
  echo "2. Reopen Arduino IDE."
  echo "3. Select: Tools > Board > SpaceMouse Compact Test"
  echo "4. Upload the firmware again."
  echo ""
else
  echo "Installation failed."
  echo ""
fi

read -p "Press Enter to close..."
