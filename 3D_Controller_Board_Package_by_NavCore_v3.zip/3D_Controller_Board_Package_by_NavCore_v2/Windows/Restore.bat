@echo off
setlocal EnableExtensions EnableDelayedExpansion

title 3D Controller Board Package by NavCore - Restore

echo ===============================================
echo  3D Controller Board Package - by NavCore
echo  Windows restore
echo ===============================================
echo.

set "AVRROOT=%LOCALAPPDATA%\Arduino15\packages\arduino\hardware\avr"
if not exist "%AVRROOT%" (
  echo ERROR: Arduino AVR Boards folder was not found.
  pause
  exit /b 1
)

set "BOARDSTXT="
for /f "delims=" %%F in ('dir /b /s "%AVRROOT%\boards.txt" 2^>nul') do (
  set "BOARDSTXT=%%F"
)

if not defined BOARDSTXT (
  echo ERROR: boards.txt was not found.
  pause
  exit /b 1
)

if not exist "!BOARDSTXT!.navcore_backup" (
  echo ERROR: No backup found:
  echo !BOARDSTXT!.navcore_backup
  pause
  exit /b 1
)

copy /Y "!BOARDSTXT!.navcore_backup" "!BOARDSTXT!" >nul
if errorlevel 1 (
  echo ERROR: Restore failed.
  pause
  exit /b 1
)

echo Restore complete. Restart Arduino IDE.
echo.
pause
exit /b 0
