@echo off
setlocal EnableExtensions EnableDelayedExpansion

title 3D Controller Board Package by NavCore - Installer

echo ===============================================
echo  3D Controller Board Package - by NavCore
echo  Windows installer
echo ===============================================
echo.

set "ADDON=%~dp0..\boards_3d_controller.txt"
if not exist "%ADDON%" (
  echo ERROR: boards_3d_controller.txt not found.
  echo Expected: %ADDON%
  pause
  exit /b 1
)

set "AVRROOT=%LOCALAPPDATA%\Arduino15\packages\arduino\hardware\avr"
if not exist "%AVRROOT%" (
  echo ERROR: Arduino AVR Boards folder was not found.
  echo.
  echo Please open Arduino IDE, install "Arduino AVR Boards" from Boards Manager,
  echo then run this installer again.
  echo.
  pause
  exit /b 1
)

set "BOARDSTXT="
for /f "delims=" %%F in ('dir /b /s "%AVRROOT%\boards.txt" 2^>nul') do (
  set "BOARDSTXT=%%F"
)

if not defined BOARDSTXT (
  echo ERROR: boards.txt was not found inside:
  echo %AVRROOT%
  pause
  exit /b 1
)

echo Found boards.txt:
echo !BOARDSTXT!
echo.

findstr /C:"navcore3d.name=3D Controller" "!BOARDSTXT!" >nul 2>nul
if !errorlevel! EQU 0 (
  echo 3D Controller board is already installed.
  echo Nothing to do.
  echo.
  pause
  exit /b 0
)

if not exist "!BOARDSTXT!.navcore_backup" (
  copy "!BOARDSTXT!" "!BOARDSTXT!.navcore_backup" >nul
  if errorlevel 1 (
    echo ERROR: Could not create backup file.
    pause
    exit /b 1
  )
  echo Backup created:
  echo !BOARDSTXT!.navcore_backup
) else (
  echo Backup already exists:
  echo !BOARDSTXT!.navcore_backup
)

echo.>>"!BOARDSTXT!"
echo.>>"!BOARDSTXT!"
type "%ADDON%" >> "!BOARDSTXT!"

if errorlevel 1 (
  echo ERROR: Could not write to boards.txt.
  pause
  exit /b 1
)

echo.
echo Installation complete.
echo Restart Arduino IDE, then select:
echo Tools ^> Board ^> Arduino AVR Boards ^> 3D Controller
echo.
pause
exit /b 0
