3D Controller Board Package - by NavCore

This package installs a custom Arduino AVR board definition named "3D Controller".

Files:
- boards_3d_controller.txt: board definition appended to Arduino AVR boards.txt
- Windows/Install.bat and Restore.bat
- macOS/Install.command and Restore.command
- Linux/Install.sh and Restore.sh
- Documentation/3D_Controller_Board_Installation_Guide.pdf

Install:
1. Install Arduino IDE 2.x.
2. In Arduino IDE, install "Arduino AVR Boards" from Boards Manager.
3. Close Arduino IDE.
4. Run the installer for your operating system.
5. Restart Arduino IDE.
6. Select Tools > Board > Arduino AVR Boards > 3D Controller.
7. Select the correct port and upload your firmware.

If needed, run the Restore script to restore the original boards.txt backup.
