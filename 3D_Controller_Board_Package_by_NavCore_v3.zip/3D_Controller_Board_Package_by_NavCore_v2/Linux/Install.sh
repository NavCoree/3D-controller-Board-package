#!/bin/bash
set -e
echo "==============================================="
echo " 3D Controller Board Package - by NavCore"
echo " Linux installer"
echo "==============================================="
echo

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ADDON="$SCRIPT_DIR/../boards_3d_controller.txt"

CANDIDATES=(
  "$HOME/.arduino15/packages/arduino/hardware/avr"
  "$HOME/.Arduino15/packages/arduino/hardware/avr"
  "$HOME/snap/arduino/current/.arduino15/packages/arduino/hardware/avr"
)

AVRROOT=""
for d in "${CANDIDATES[@]}"; do
  if [ -d "$d" ]; then
    AVRROOT="$d"
    break
  fi
done

if [ ! -f "$ADDON" ]; then
  echo "ERROR: boards_3d_controller.txt not found."
  exit 1
fi

if [ -z "$AVRROOT" ]; then
  echo "ERROR: Arduino AVR Boards folder was not found."
  echo "Install Arduino AVR Boards from Boards Manager, then run again."
  exit 1
fi

BOARDSTXT="$(find "$AVRROOT" -name boards.txt -type f | sort -V | tail -n 1)"
if [ -z "$BOARDSTXT" ]; then
  echo "ERROR: boards.txt was not found."
  exit 1
fi

echo "Found boards.txt:"
echo "$BOARDSTXT"
echo

if grep -q "navcore3d.name=3D Controller" "$BOARDSTXT"; then
  echo "3D Controller board is already installed."
  exit 0
fi

if [ ! -f "$BOARDSTXT.navcore_backup" ]; then
  cp "$BOARDSTXT" "$BOARDSTXT.navcore_backup"
  echo "Backup created: $BOARDSTXT.navcore_backup"
else
  echo "Backup already exists: $BOARDSTXT.navcore_backup"
fi

printf "\n\n" >> "$BOARDSTXT"
cat "$ADDON" >> "$BOARDSTXT"

echo
echo "Installation complete."
echo "Restart Arduino IDE, then select:"
echo "Tools > Board > Arduino AVR Boards > 3D Controller"
