#!/bin/bash
set -e
echo "==============================================="
echo " 3D Controller Board Package - by NavCore"
echo " Linux restore"
echo "==============================================="
echo

CANDIDATES=(
  "$HOME/.arduino15/packages/arduino/hardware/avr"
  "$HOME/.Arduino15/packages/arduino/hardware/avr"
  "$HOME/snap/arduino/current/.arduino15/packages/arduino/hardware/avr"
)

AVRROOT=""
for d in "${CANDIDATES[@]}"; do
  if [ -d "$d" ]; then
    AVRROOT="$d"
    break
  fi
done

if [ -z "$AVRROOT" ]; then
  echo "ERROR: Arduino AVR Boards folder was not found."
  exit 1
fi

BOARDSTXT="$(find "$AVRROOT" -name boards.txt -type f | sort -V | tail -n 1)"
if [ -z "$BOARDSTXT" ]; then
  echo "ERROR: boards.txt was not found."
  exit 1
fi

if [ ! -f "$BOARDSTXT.navcore_backup" ]; then
  echo "ERROR: No backup found: $BOARDSTXT.navcore_backup"
  exit 1
fi

cp "$BOARDSTXT.navcore_backup" "$BOARDSTXT"
echo "Restore complete. Restart Arduino IDE."
