HackMan3D Orbit Controller - macOS V2 Automated Installer - FIXED

Use this version instead of the previous one.

How to use:
1. Unzip this folder.
2. Right-click Install_macOS_V2_FIXED.command.
3. Choose Open.
4. Confirm Open if macOS asks.
5. Choose the correct boards.txt file if several are found.
6. Restart Arduino IDE.
7. Select:
   Tools > Board > SpaceMouse Compact Test
8. Upload the Orbit Controller firmware again.

What it does:
- Searches more Arduino locations
- Supports Arduino IDE 1.x and 2.x paths
- Creates a backup of boards.txt
- Uses sudo if the file is protected
- Replaces an existing navcore3d entry with the macOS V2 version
