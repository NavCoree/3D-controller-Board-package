#!/bin/bash
set -e
clear
echo "==============================================="
echo " 3D Controller Board Package - by NavCore"
echo " macOS restore"
echo "==============================================="
echo

AVRROOT="$HOME/Library/Arduino15/packages/arduino/hardware/avr"
BOARDSTXT="$(find "$AVRROOT" -name boards.txt -type f | sort -V | tail -n 1)"

if [ -z "$BOARDSTXT" ]; then
  echo "ERROR: boards.txt was not found."
  read -p "Press Enter to close..."
  exit 1
fi

if [ ! -f "$BOARDSTXT.navcore_backup" ]; then
  echo "ERROR: No backup found: $BOARDSTXT.navcore_backup"
  read -p "Press Enter to close..."
  exit 1
fi

cp "$BOARDSTXT.navcore_backup" "$BOARDSTXT"
echo "Restore complete. Restart Arduino IDE."
read -p "Press Enter to close..."
